/*
 * Copyright (C) 2014 sydnipeterson
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package spacetrader;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import javafx.stage.Modality;
import javafx.scene.Scene;
import javafx.scene.layout.VBoxBuilder;
import javafx.scene.text.Text;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

/**
 * FXML Controller class
 *
 * @author sydnipeterson
 */
public class UniverseScreenController implements Initializable {

    @FXML
    private BorderPane MenuButton;
    @FXML
    private ImageView gal1;
    @FXML
    private ImageView gal4;
    @FXML
    private ImageView gal7;
    @FXML
    private ImageView gal5;
    @FXML
    private ImageView gal2;
    @FXML
    private ImageView gal8;
    @FXML
    private ImageView gal3;
    @FXML
    private ImageView gal6;
    @FXML
    private ImageView gal0;
    @FXML
    private Menu fuelTab;
    private Player player = GameInstance.getInstance().getPlayer();
    private Ship ship = GameInstance.getInstance().getPlayer().getShip();
    private Universe universe = GameInstance.getInstance().getUniverse();
    private Game game = GameInstance.getInstance();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
	game.setCurrentScreen("UniverseScreen.fxml");
	// TODO
	// fuelTab.setText("Fuel: ");
	fuelTab.setText("Fuel: " + Integer.toString(ship.getFuel()));
    }

    /**
     * Returns to main menu when clicked
     *
     * @event the event that triggers this action
     */
    @FXML
    private void ReturnMainMenu(MouseEvent event) throws Exception {
	Parent root = FXMLLoader
		.load(getClass().getResource("RootWindow.fxml"));
	Stage stage = new Stage();
	stage.setScene(new Scene(root));
	stage.show();

	// hide this current window (if this is whant you want
	((Node) (event.getSource())).getScene().getWindow().hide();
    }

    /**
     * Takes player to first galaxy
     *
     * @event the event that triggers this action
     */
    @FXML
    private void goToGal1(MouseEvent event) throws Exception {
	if (ship.getFuel() > 0) {
	    ship.setFuel(ship.getFuel() - 1);

	    // Game game = GameInstance.getInstance();
	    // game.getPlayer().setCurrentLocation(game.getUniverse().get(0).getPlanets().get(0));
	    // look at this ^^^
	    Parent root = FXMLLoader.load(getClass().getResource(
		    "GalOneScreen.fxml"));
	    Stage stage = new Stage();
	    stage.setScene(new Scene(root));
	    stage.show();

	    // hide this current window (if this is whant you want
	    ((Node) (event.getSource())).getScene().getWindow().hide();
	} else {
	    Stage dialogStage = new Stage();
	    dialogStage.initModality(Modality.WINDOW_MODAL);
	    dialogStage
		    .setScene(new Scene(
			    VBoxBuilder
				    .create()
				    .children(
					    new Text(
						    "You do not have enough fuel to travel there."))
				    .alignment(Pos.CENTER)
				    .padding(new Insets(30)).build()));
	    dialogStage.show();
	}

    }

    /**
     * Takes player to fourth galaxy
     *
     * @event the event that triggers this action
     */
    @FXML
    private void goToGal4(MouseEvent event) throws Exception {
	if (ship.getFuel() > 0) {
	    ship.setFuel(ship.getFuel() - 1);

	    // Game game = GameInstance.getInstance();
	    // game.getPlayer().setCurrentLocation(game.getUniverse().get(0).getPlanets().get(0));
	    // look at this ^^^
	    Parent root = FXMLLoader.load(getClass().getResource(
		    "GalFourScreen.fxml"));
	    Stage stage = new Stage();
	    stage.setScene(new Scene(root));
	    stage.show();

	    // hide this current window (if this is whant you want
	    ((Node) (event.getSource())).getScene().getWindow().hide();
	} else {
	    Stage dialogStage = new Stage();
	    dialogStage.initModality(Modality.WINDOW_MODAL);
	    dialogStage
		    .setScene(new Scene(
			    VBoxBuilder
				    .create()
				    .children(
					    new Text(
						    "You do not have enough fuel to travel there."))
				    .alignment(Pos.CENTER)
				    .padding(new Insets(30)).build()));
	    dialogStage.show();
	}

    }

    /**
     * Takes player to seventh galaxy
     *
     * @event the event that triggers this action
     */
    @FXML
    private void goToGal7(MouseEvent event) throws Exception {
	if (ship.getFuel() > 0) {
	    ship.setFuel(ship.getFuel() - 1);

	    // Game game = GameInstance.getInstance();
	    // game.getPlayer().setCurrentLocation(game.getUniverse().get(0).getPlanets().get(0));
	    // look at this ^^^
	    Parent root = FXMLLoader.load(getClass().getResource(
		    "GalSevenScreen.fxml"));
	    Stage stage = new Stage();
	    stage.setScene(new Scene(root));
	    stage.show();

	    // hide this current window (if this is whant you want
	    ((Node) (event.getSource())).getScene().getWindow().hide();
	} else {
	    Stage dialogStage = new Stage();
	    dialogStage.initModality(Modality.WINDOW_MODAL);
	    dialogStage
		    .setScene(new Scene(
			    VBoxBuilder
				    .create()
				    .children(
					    new Text(
						    "You do not have enough fuel to travel there."))
				    .alignment(Pos.CENTER)
				    .padding(new Insets(30)).build()));
	    dialogStage.show();
	}

    }

    /**
     * Takes player to fifth galaxy
     *
     * @event the event that triggers this action
     */
    @FXML
    private void goToGal5(MouseEvent event) throws Exception {
	if (ship.getFuel() > 0) {
	    ship.setFuel(ship.getFuel() - 1);

	    // Game game = GameInstance.getInstance();
	    // game.getPlayer().setCurrentLocation(game.getUniverse().get(0).getPlanets().get(0));
	    // look at this ^^^
	    Parent root = FXMLLoader.load(getClass().getResource(
		    "GalFiveScreen.fxml"));
	    Stage stage = new Stage();
	    stage.setScene(new Scene(root));
	    stage.show();

	    // hide this current window (if this is whant you want
	    ((Node) (event.getSource())).getScene().getWindow().hide();
	} else {
	    Stage dialogStage = new Stage();
	    dialogStage.initModality(Modality.WINDOW_MODAL);
	    dialogStage
		    .setScene(new Scene(
			    VBoxBuilder
				    .create()
				    .children(
					    new Text(
						    "You do not have enough fuel to travel there."))
				    .alignment(Pos.CENTER)
				    .padding(new Insets(30)).build()));
	    dialogStage.show();
	}

    }

    /**
     * Takes player to second galaxy
     *
     * @event the event that triggers this action
     */
    @FXML
    private void goToGal2(MouseEvent event) throws Exception {
	if (ship.getFuel() > 0) {
	    ship.setFuel(ship.getFuel() - 1);

	    // Game game = GameInstance.getInstance();
	    // game.getPlayer().setCurrentLocation(game.getUniverse().get(0).getPlanets().get(0));
	    // look at this ^^^
	    Parent root = FXMLLoader.load(getClass().getResource(
		    "GalTwoScreen.fxml"));
	    Stage stage = new Stage();
	    stage.setScene(new Scene(root));
	    stage.show();

	    // hide this current window (if this is whant you want
	    ((Node) (event.getSource())).getScene().getWindow().hide();
	} else {
	    Stage dialogStage = new Stage();
	    dialogStage.initModality(Modality.WINDOW_MODAL);
	    dialogStage
		    .setScene(new Scene(
			    VBoxBuilder
				    .create()
				    .children(
					    new Text(
						    "You do not have enough fuel to travel there."))
				    .alignment(Pos.CENTER)
				    .padding(new Insets(30)).build()));
	    dialogStage.show();
	}

    }

    /**
     * Takes player to eigth galaxy
     *
     * @event the event that triggers this action
     */
    @FXML
    private void goToGal8(MouseEvent event) throws Exception {
	if (ship.getFuel() > 0) {
	    ship.setFuel(ship.getFuel() - 1);

	    // Game game = GameInstance.getInstance();
	    // game.getPlayer().setCurrentLocation(game.getUniverse().get(0).getPlanets().get(0));
	    // look at this ^^^
	    Parent root = FXMLLoader.load(getClass().getResource(
		    "GalEightScreen.fxml"));
	    Stage stage = new Stage();
	    stage.setScene(new Scene(root));
	    stage.show();

	    // hide this current window (if this is whant you want
	    ((Node) (event.getSource())).getScene().getWindow().hide();
	} else {
	    Stage dialogStage = new Stage();
	    dialogStage.initModality(Modality.WINDOW_MODAL);
	    dialogStage
		    .setScene(new Scene(
			    VBoxBuilder
				    .create()
				    .children(
					    new Text(
						    "You do not have enough fuel to travel there."))
				    .alignment(Pos.CENTER)
				    .padding(new Insets(30)).build()));
	    dialogStage.show();
	}

    }

    /**
     * Takes player to three galaxy
     *
     * @event the event that triggers this action
     */
    @FXML
    private void goToGal3(MouseEvent event) throws Exception {
	if (ship.getFuel() > 0) {
	    ship.setFuel(ship.getFuel() - 1);

	    // Game game = GameInstance.getInstance();
	    // game.getPlayer().setCurrentLocation(game.getUniverse().get(0).getPlanets().get(0));
	    // look at this ^^^
	    Parent root = FXMLLoader.load(getClass().getResource(
		    "GalThreeScreen.fxml"));
	    Stage stage = new Stage();
	    stage.setScene(new Scene(root));
	    stage.show();

	    // hide this current window (if this is whant you want
	    ((Node) (event.getSource())).getScene().getWindow().hide();
	} else {
	    Stage dialogStage = new Stage();
	    dialogStage.initModality(Modality.WINDOW_MODAL);
	    dialogStage
		    .setScene(new Scene(
			    VBoxBuilder
				    .create()
				    .children(
					    new Text(
						    "You do not have enough fuel to travel there."))
				    .alignment(Pos.CENTER)
				    .padding(new Insets(30)).build()));
	    dialogStage.show();
	}

    }

    /**
     * Takes player to sixth galaxy
     *
     * @event the event that triggers this action
     */
    @FXML
    private void goToGal6(MouseEvent event) throws Exception {
	if (ship.getFuel() > 0) {
	    ship.setFuel(ship.getFuel() - 1);

	    // Game game = GameInstance.getInstance();
	    // game.getPlayer().setCurrentLocation(game.getUniverse().get(0).getPlanets().get(0));
	    // look at this ^^^
	    Parent root = FXMLLoader.load(getClass().getResource(
		    "GalSixScreen.fxml"));
	    Stage stage = new Stage();
	    stage.setScene(new Scene(root));
	    stage.show();

	    // hide this current window (if this is whant you want
	    ((Node) (event.getSource())).getScene().getWindow().hide();
	} else {
	    Stage dialogStage = new Stage();
	    dialogStage.initModality(Modality.WINDOW_MODAL);
	    dialogStage
		    .setScene(new Scene(
			    VBoxBuilder
				    .create()
				    .children(
					    new Text(
						    "You do not have enough fuel to travel there."))
				    .alignment(Pos.CENTER)
				    .padding(new Insets(30)).build()));
	    dialogStage.show();
	}

    }

    /**
     * Takes player to nineth (0) galaxy
     *
     * @event the event that triggers this action
     */
    @FXML
    private void goToGal0(MouseEvent event) throws Exception {
	if (ship.getFuel() > 0) {
	    ship.setFuel(ship.getFuel() - 1);

	    // Game game = GameInstance.getInstance();
	    // game.getPlayer().setCurrentLocation(game.getUniverse().get(0).getPlanets().get(0));
	    // look at this ^^^
	    Parent root = FXMLLoader.load(getClass().getResource(
		    "GalNineScreen.fxml"));
	    Stage stage = new Stage();
	    stage.setScene(new Scene(root));
	    stage.show();

	    // hide this current window (if this is whant you want
	    ((Node) (event.getSource())).getScene().getWindow().hide();
	} else {
	    Stage dialogStage = new Stage();
	    dialogStage.initModality(Modality.WINDOW_MODAL);
	    dialogStage
		    .setScene(new Scene(
			    VBoxBuilder
				    .create()
				    .children(
					    new Text(
						    "You do not have enough fuel to travel there."))
				    .alignment(Pos.CENTER)
				    .padding(new Insets(30)).build()));
	    dialogStage.show();
	}

    }

    /**
     * Saves the game
     *
     * @param event
     *            mouse event of when user clicks on "SAVE" button
     */
    @FXML
    private void saveGame(MouseEvent event) {
	GameInstance.saveModelBinary();
    }

    /**
     * Exits the game and returns to the main screen
     *
     * @param event
     *            mouse event of when user clicks on "EXIT" button
     */
    @FXML
    private void exit(MouseEvent event) throws Exception {
	Parent root = FXMLLoader
		.load(getClass().getResource("RootWindow.fxml"));
	Stage stage = new Stage();
	stage.setScene(new Scene(root));
	stage.show();

	// hide this current window (if this is whant you want
	((Node) (event.getSource())).getScene().getWindow().hide();
    }

}
